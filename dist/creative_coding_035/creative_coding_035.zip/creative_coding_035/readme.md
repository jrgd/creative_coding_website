read data from text string

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>