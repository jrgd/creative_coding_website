Simpler version of 027; introducing loops and variables (HTML, jQuery, CSS)

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>