basic div ABC typeface (HTML intro) 

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>