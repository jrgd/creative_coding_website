Gradients generator with steps and colour palette.

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>