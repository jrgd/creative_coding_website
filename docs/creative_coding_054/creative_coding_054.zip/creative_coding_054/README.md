macOS automatic screenshots from the command line

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>

## Automatic Screenshoting

Req. macOs, AppleScript, bash

Using a basic loop to take multiple screenshot of webpages without an operator.
This could easily use a text file with urls (one per line) as a source (instead of the naive variable-based naming).

Note: remember to `chmod +x ./ccss.sh`