Drawing a faded rectangle, then drawing the same shape but moving the top-right point 10px to the right—over and over (SVG, loop)

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>