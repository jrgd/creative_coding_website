A prototype tool for a story generator/writer.
It works like for text based games and explore the notion of a self replicating tool that is also the product. A bit like a reprap but for narrations.