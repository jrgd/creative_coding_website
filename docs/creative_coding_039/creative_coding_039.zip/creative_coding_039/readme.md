Copy current frame from a video into a canvas, every 1/30th of a sec (works in Chrome and Firefox, due to source file format)

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>