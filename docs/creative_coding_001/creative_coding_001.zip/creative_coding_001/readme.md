Draw a parametric box with loops on X,Y (SVG)

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>