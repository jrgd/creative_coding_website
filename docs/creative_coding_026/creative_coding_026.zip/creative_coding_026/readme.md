basic div chess board (HTML intro)

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>