move a square within a parametric grid

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>