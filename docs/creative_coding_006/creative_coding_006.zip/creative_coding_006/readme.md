No animation: the image is calculated and displayed in one go. Adapted from 005. (Canvas) 

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>