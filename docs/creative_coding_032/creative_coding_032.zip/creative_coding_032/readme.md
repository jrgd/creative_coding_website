Copy image to new image (lower resolution), then parse pixels colors from images and create svg (jquery, canvas, svg)

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>