(HTML + jQuery + CSS) simpler version of 027; introducing loops and variables

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>