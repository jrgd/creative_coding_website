Reactive mouse hover Trim logotyype (Canvas) 

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>