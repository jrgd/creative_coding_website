Glitch: draw a line over an image usign the clicked pixel colour

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>