things to consider
- save the state, default options, etc. cookies/localstorage?
- saving the state/style of each cells
- export the background-color of the cell
- ability to export to different format: svg, canvas
- ability to assign a shape a letter; ability to create the characters map
