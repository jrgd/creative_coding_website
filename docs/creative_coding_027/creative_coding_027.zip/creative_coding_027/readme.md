 ground ui work for a pixel drawing tool (jQuery, HTML)

 # Creative Coding / Visual Experiments
 ## an ongoing coding/research seminar
 <http://creativecoding.xyz>