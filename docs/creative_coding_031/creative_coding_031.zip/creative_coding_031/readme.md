simple SVG shapes with basic coordinates (SVG)

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>