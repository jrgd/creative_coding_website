sliced images animations/transitions

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>

## sliced images animations/transitions
Css transitions/animations on a jquery basic slideshow.

<video width="433" height="576" controls>
  <source src="./Screen Recording 2022-04-01 at 16.04.54.mp4" type="video/mp4">
</video>