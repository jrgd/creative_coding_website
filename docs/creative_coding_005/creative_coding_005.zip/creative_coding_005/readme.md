Drawing line by line with a repeated colour palette on HTML Canvas; adapted from 003. (Canvas) 

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>