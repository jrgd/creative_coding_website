move a square within a parametric grid: keyboard and mouse interactions; draw with pixel, brushes, lines

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>