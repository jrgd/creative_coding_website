keyboard input, basic template

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>