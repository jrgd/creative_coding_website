Slitscan a video; extension of 039. Copy 20 pixels wide vertical band from a video every XXth seconds and paste it next to previous vertical bands in a Canvas image.

# Creative Coding / Visual Experiments
## an ongoing coding/research seminar
<http://creativecoding.xyz>