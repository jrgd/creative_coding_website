a simple software to write and think

# Creative Coding / Information Pipeline
## an ongoing coding/research seminar
<http://creativecoding.xyz>

## a simple software to write and think
It's essentially a HTML page with ajax query onto PHP scripts to read and write files.
It's still very rough on the edges.

*How to use* 
ie: notes to future-self, in a few months.

- ```composer install```
- ```valet link writingthinking```
- and then use a browser to visit the page writingthinking.test

*Documentation*
Operators and meta/headers for txt and markdown files

*Thinking behind the project*
This takes place directly in the ./documents 